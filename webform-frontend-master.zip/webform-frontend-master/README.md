# Web-form Frontend

This is a seperate application for creating the reports for SEDA Application
