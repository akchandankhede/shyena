import React from 'react';
import Checkout from './components/Checkout.jsx';

function App() {
  return (
    <div className = 'container'>
      <Checkout/>
    </div>)
}

export default App;
